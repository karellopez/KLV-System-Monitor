#!/usr/bin/env bash
set -euo pipefail

# ──────────────────────────────────────────────────────────────
# Configuration
# ──────────────────────────────────────────────────────────────
APP_NAME="KLVSystemMonitor"
INSTALL_DIR="$HOME/KLVSystemMonitor"
PORTABLE_PYTHON_URL="https://raw.githubusercontent.com/karellopez/KLV-System-Monitor/main/external/python-embed/python-3.10.13%2B20240107-x86_64-unknown-linux-gnu-install_only.zip"
ENV_DIR="$INSTALL_DIR/env"
PYTHON_BIN="$INSTALL_DIR/bin/python3.10"
DESKTOP_DIR="$HOME/Desktop"
APPDIR="$HOME/.local/share/applications"

mkdir -p "$INSTALL_DIR" "$APPDIR"

# ──────────────────────────────────────────────────────────────
# Step 1: Detect usable Python 3.10 or download portable version
# ──────────────────────────────────────────────────────────────
USE_PORTABLE=true

if $USE_PORTABLE; then
    echo "[*] Downloading portable Python 3.10..."
    cd "$INSTALL_DIR"
    ZIP_NAME="$(basename "$PORTABLE_PYTHON_URL" | sed 's/%2B/+/g')"  # decode URL-encoded '+'
    wget -q --show-progress -O "$ZIP_NAME" "$PORTABLE_PYTHON_URL"
    echo "[*] Unzipping..."
    unzip -q "$ZIP_NAME"
    rm "$ZIP_NAME"
    # optional: if decompress in a subdirectory, move it
    if [ -d "python" ]; then
        mv python/* .
        rmdir python
    fi
    PYTHON="$PYTHON_BIN"
fi

# ──────────────────────────────────────────────────────────────
# Step 2: Create virtual environment and install KLV System Monitor
# ──────────────────────────────────────────────────────────────
echo "[*] Creating virtual environment..."
"$PYTHON" -m venv "$ENV_DIR"
source "$ENV_DIR/bin/activate"
pip install --upgrade pip
pip install klv-system-monitor
deactivate

# ──────────────────────────────────────────────────────────────
# Step 3: Create launcher script
# ──────────────────────────────────────────────────────────────
RUN_SCRIPT="$INSTALL_DIR/run_KLVSystemMonitor.sh"
cat > "$RUN_SCRIPT" <<EOF
#!/usr/bin/env bash
source "$ENV_DIR/bin/activate"
klvtop
EOF
chmod +x "$RUN_SCRIPT"

# ──────────────────────────────────────────────────────────────
# Step 4: Create uninstaller script
# ──────────────────────────────────────────────────────────────
UNINSTALL_SCRIPT="$INSTALL_DIR/uninstall_KLVSystemMonitor.sh"
cat > "$UNINSTALL_SCRIPT" <<EOF
#!/usr/bin/env bash
echo "[*] Removing $INSTALL_DIR..."
rm -rf "$INSTALL_DIR"

echo "[*] Removing launchers..."
rm -f "$DESKTOP_DIR/KLVSystemMonitor.desktop"
rm -f "$DESKTOP_DIR/Uninstall_KLVSystemMonitor.desktop"
rm -f "$APPDIR/KLVSystemMonitor.desktop"
rm -f "$APPDIR/Uninstall_KLVSystemMonitor.desktop"

echo "[*] Removing PATH override from ~/.bashrc..."
sed -i '/# >>> KLVSystemMonitor Python/,/# <<< KLVSystemMonitor Python/d' "$HOME/.bashrc"

echo "[*] Uninstallation complete."
EOF
chmod +x "$UNINSTALL_SCRIPT"

# ──────────────────────────────────────────────────────────────
# Step 5: Create desktop launchers
# ──────────────────────────────────────────────────────────────
if [[ -d "$DESKTOP_DIR" ]]; then
    echo "[*] Creating desktop shortcuts..."

    # Run launcher
    cat > "$APPDIR/KLVSystemMonitor.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=KLV System Monitor
Comment=Launch KLV System Monitor
Exec=$RUN_SCRIPT
Terminal=true
Icon=utilities-terminal
EOF
    cp "$APPDIR/KLVSystemMonitor.desktop" "$DESKTOP_DIR/"
    chmod +x "$DESKTOP_DIR/KLVSystemMonitor.desktop"

    # Uninstall launcher
    cat > "$APPDIR/Uninstall_KLVSystemMonitor.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Uninstall KLV System Monitor
Comment=Completely remove KLV System Monitor
Exec=$UNINSTALL_SCRIPT
Terminal=true
Icon=utilities-terminal
EOF
    cp "$APPDIR/Uninstall_KLVSystemMonitor.desktop" "$DESKTOP_DIR/"
    chmod +x "$DESKTOP_DIR/Uninstall_KLVSystemMonitor.desktop"
else
    echo "[!] Desktop directory not found. Skipping desktop icon creation."
fi

# ──────────────────────────────────────────────────────────────
# Step 6: Set portable Python as default (user-only)
# ──────────────────────────────────────────────────────────────
if ! grep -q '# >>> KLVSystemMonitor Python' "$HOME/.bashrc"; then
    echo "[*] Setting portable Python as the default Python in ~/.bashrc..."
    cat >> "$HOME/.bashrc" <<EOF

# >>> KLVSystemMonitor Python
export PATH="$INSTALL_DIR/bin:\$PATH"
# <<< KLVSystemMonitor Python
EOF
fi

# ──────────────────────────────────────────────────────────────
# Done!
# ──────────────────────────────────────────────────────────────
echo ""
echo "✅ KLV System Monitor was successfully installed!"
echo "→ Run it via the desktop icon or with:  bash $RUN_SCRIPT"
echo "→ Uninstall it with:                   bash $UNINSTALL_SCRIPT"
echo "→ Restart your terminal to use Python 3.10 by default."

